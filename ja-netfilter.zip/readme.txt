Operation guide: 
    1. Add -javaagent:/path/to/ja-netfilter.jar to your vmoptions (manual or auto), No need to add the =jetbrains suffix
    2. You can use the key on the page https://jet.bytebarn.top/ for testing, or use license server https://jbls.bytebarn.top/ for testing
    3. Don't care about the activation time, it is a fallback license and will not expire
    4. To obtain the latest activation patch, please follow the WeChat public account "Bytebarn"
    5. This is only for learning and testing purposes, please do not use it for commercial purposes
    6. If necessary, please go to https://jetbrains.com/ to purchase genuine IDE tools

Enjoy it~

JBR17:
    add these 2 lines to your vmoptions file: (for manual, without any whitespace chars)
    --add-opens=java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED
    --add-opens=java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED

NEW: 
    Auto configure vmoptions (It is recommended to execute the script once before introducing the patch):
        macOS or Linux: execute "scripts/install.sh"
        Windows: double click to execute "scripts\install-current-user.vbs" (For current user)
                                         "scripts\install-all-users.vbs" (For all users)